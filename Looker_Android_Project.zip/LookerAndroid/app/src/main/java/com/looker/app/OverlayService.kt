package com.looker.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var box: LinearLayout

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 28, 20)
            background = GradientDrawable().apply {
                setColor(Color.rgb(15,18,23)); cornerRadius = 24f
                setStroke(3, Color.rgb(0,230,118))
            }
            addView(label("👁 LOOKER", 18, Color.rgb(0,230,118)))
            addView(label("PREDICTION", 13, Color.LTGRAY))
            addView(label("STEP: --", 24, Color.WHITE))
            addView(label("TARGET: --x", 20, Color.WHITE))
        }
        val p = WindowManager.LayoutParams(320, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            -3).apply { gravity = Gravity.TOP or Gravity.START; x=30; y=180 }
        var dx=0; var dy=0
        box.setOnTouchListener { _, e ->
            when(e.action) {
                MotionEvent.ACTION_DOWN -> { dx=(e.rawX-p.x).toInt(); dy=(e.rawY-p.y).toInt(); true }
                MotionEvent.ACTION_MOVE -> { p.x=(e.rawX-dx).toInt(); p.y=(e.rawY-dy).toInt(); wm.updateViewLayout(box,p); true }
                else -> false
            }
        }
        wm.addView(box,p)
        return START_STICKY
    }
    private fun label(s:String,size:Int,c:Int)=TextView(this).apply {
        text=s; textSize=size.toFloat(); setTextColor(c); setPadding(0,5,0,5)
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy(){ if(::box.isInitialized) wm.removeView(box); super.onDestroy() }
}
